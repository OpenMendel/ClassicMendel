README file for Mendel installation on Unix-derived systems

The directory containing the mendel executable needs to be in the PATH
for Mendel to work properly. To accomplish this, please add the following
to your startup scripts according to the shell you are running.


For csh and tcsh users - 
Add the following to your $HOME/.cshrc or $HOME/.tcshrc file:
set path ($path /[mendel-install-dir])

e.g., if you install the mendel executable within the directory
/home/username/Mendel, then you should use:
set path ($path /home/username/Mendel)

You may run "source $HOME/.cshrc" or "source $HOME/.tcshrc" for the system
to read the changed startup file again and for the PATH to take effect.


For bash users - 
Add the following to your $HOME/.bashrc or $HOME/.bash_profile file:
PATH=$PATH:/[mendel-install-dir]

e.g., if you install the mendel executable within the directory
/home/username/Mendel, then you should use:
PATH=$PATH:/home/username/Mendel

You may run "source $HOME/.bashrc" or "source $HOME/.bash_profile" for the
system to read the changed startup file again and for the PATH to take effect.

